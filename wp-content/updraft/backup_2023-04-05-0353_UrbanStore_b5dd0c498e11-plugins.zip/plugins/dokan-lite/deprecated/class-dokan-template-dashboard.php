<?php

use WeDevs\Dokan\Dashboard\Templates\Dashboard;

class Dokan_Template_Dashboard extends Dashboard {}
