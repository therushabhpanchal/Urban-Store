<?php

use WeDevs\Dokan\REST\ProductController;

class Dokan_REST_Product_Controller extends ProductController {

    public function __construct() {}
}
