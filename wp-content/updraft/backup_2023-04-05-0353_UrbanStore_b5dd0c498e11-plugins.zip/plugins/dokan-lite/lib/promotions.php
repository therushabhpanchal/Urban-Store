<?php

use WeDevs\Dokan\Admin\Promotion;

class WeDevs_Promotion extends Promotion {}
